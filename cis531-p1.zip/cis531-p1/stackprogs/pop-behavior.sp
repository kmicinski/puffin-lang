push 10
push 20
pop
print
